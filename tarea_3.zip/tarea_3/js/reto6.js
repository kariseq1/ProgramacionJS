function c1(){
    document.getElementById("celular").src ="img/azul.png";
    document.getElementById("color").innerHTML= "AZUL CLÁSICO";
}

function c2(){
    document.getElementById("celular").src ="img/black.png";
    document.getElementById("color").innerHTML= "NEGRO ESPACIAL";
}

function c3(){
    document.getElementById("celular").src ="img/blanco.png";
    document.getElementById("color").innerHTML= "BLANCO ESMERALDA";
}

function c4(){
    document.getElementById("celular").src ="img/rojo.png";
    document.getElementById("color").innerHTML= "ROJO VINO";
}

